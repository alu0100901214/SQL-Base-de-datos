#include "matrices_3.hpp"
#include <iomanip>

using namespace std;


//========================================================================================
// Métodos privados.
//========================================================================================



vector_inx_t matrix_t::pos(matrix_inx_t i,matrix_inx_t j)
{
	if(traspuesta_==false){
	
		if ((i<1)||(i>m_)||(j<1)||(j>n_)){
		cerr << "Error accediendo a matriz"<< endl;
		return 0;
        }

		return (i-1)*n_+j-1;
	}else{
		
		if ((i<1)||(i>n_)||(j<1)||(j>m_)){
		cerr << "Error accediendo a matriz"<< endl;
		return 0;
        }

		return (j-1)*n_+i-1;
	}

}

vector_inx_t matrix_t::pos(matrix_inx_t i,matrix_inx_t j) const
{
	if(traspuesta_==false){
	
		if ((i<1)||(i>m_)||(j<1)||(j>n_)){
		cerr << "Error accediendo a matriz"<< endl;
		return 0;
        }

		return (i-1)*n_+j-1;
	}else{
		
		if ((i<1)||(i>n_)||(j<1)||(j>m_)){
		cerr << "Error accediendo a matriz"<< endl;
		return 0;
        }

		return (j-1)*n_+i-1;
	}


}


void matrix_t::crearMatriz(void) 
{
	M_= new matrix_item_t [m_*n_];	// Crea un vector de mxn elementos. 
	
	if (M_==NULL)  		// Si ha fallado la reserva de memoria. 
		cerr << "Error creando matriz." << endl;
}		



void matrix_t::destruirMatriz(void)
{
	if (M_!=NULL){
		delete [] M_;		// Libera la memoria previamente reservada para la matriz.
		M_=NULL;		// Asigna NULL al puntero.
	}

	m_=0;
	n_=0;
}




void matrix_t::redimensiona(matrix_inx_t m,matrix_inx_t n)
{
	destruirMatriz();

	m_=m;
	n_=n;

	crearMatriz();
}




//========================================================================================
// Métodos públicos.
//========================================================================================

matrix_t::matrix_t(matrix_inx_t m,matrix_inx_t n):
M_(NULL),
m_(m),
n_(n)
{
	crearMatriz();
}	




matrix_t::matrix_t(void):
M_(NULL),
m_(0),
n_(0)
{}		



matrix_t::~matrix_t(void)
{
	destruirMatriz();
}


matrix_item_t matrix_t::get_matrix_item(matrix_inx_t i,matrix_inx_t j) const
{	
	//if(traspuesta_==false)
	return M_[pos(i,j)];
	//else
	return M_[pos(j,i)];
}


void matrix_t::set_matrix_item(matrix_inx_t i,matrix_inx_t j,matrix_item_t it)
{
	M_[pos(i,j)]=it;	
}




matrix_inx_t matrix_t::get_m(void) const
{
	if(traspuesta_==false)
	return m_;
	else
	return n_;	
}




matrix_inx_t matrix_t::get_n(void) const
{	
	if(traspuesta_==false)
	return n_;
	else
	return m_;
}




istream& matrix_t::read(istream& is)
{
	int m,n;

	is >> m >> n;

	redimensiona(m,n);

	const int sz=m*n;

	for(int i=0;i<sz;i++)
		is >> M_[i];
	
}



ostream& matrix_t::write(ostream& os) const
{

	os << setw(10) << get_m() << setw(10) << get_n() << endl;

	for(int i=1;i <= get_m();i++){

		for(int j=1;j <= get_n() ;j++)
			os << setw(10) << fixed << setprecision(6) << get_matrix_item(i,j);
		
		os << endl;
	}
}

void matrix_t::write(void) const 
{

	for(int i=1;i <= get_m();i++){
		cout << "|";
		for(int j=1;j <= get_n();j++)
			cout << setw(10) << fixed << setprecision(6) << get_matrix_item(i,j);
		cout << " |";
		cout << endl;
	}

	cout << endl;
}
	
	
	//Bool igual menor mayor y zero
	//Compara si a = b
	bool matrix_t::igual(matrix_item_t a, matrix_item_t b, double eps){
		if(fabs(a-b)<eps)
		return true;
		else
		return false;
	}
	
	//Compara si a < b
	bool matrix_t::menor(matrix_item_t a, matrix_item_t b, double eps){
		if(a-b<-eps)
		return true;
		else
		return false;
	}
	
	//Compara si a > b
	bool matrix_t::mayor(matrix_item_t a, matrix_item_t b, double eps){
		if(a-b>eps){
		return true;
		cout << "entro" << endl;
		}else{
		return false;
		cout << " no entro " << endl;
	}
	}
	
	//Compara si a = 0
	bool matrix_t::zero(matrix_item_t a, double eps){ 
		if(fabs(a)<eps)
		return true;
		else
		return false;
	}
	
	// Modificación
	// a es el doble que b
	bool matrix_t::doble(matrix_item_t a, matrix_item_t b , double eps){
		
		if(  (2*b-a) < eps  )
		return true;
		else 
		return false;
	}
	
	
	// Función filtrar
	void matrix_t::filtra(matrix_t& M, matrix_item_t it, double eps){
		
		M.redimensiona(m_,n_);
		
		for(int i=1; i<=get_m(); i++){
			for(int j=1; j<=get_n();j++){
				if(igual(get_matrix_item(i,j),it,eps)){
					M.set_matrix_item(i,j,get_matrix_item(i,j));
				}else{
					M.set_matrix_item(i,j,0.0);
				}
			}
		}
	}
	
	
	// Función trasponer
	void matrix_t::trasponer(void){
		traspuesta_=true;
	}
	
	
	
	
	
	
	
	
	// Funciones de práctica
	void matrix_t::cuenta_zero(matrix_t& M, double eps){
		int cuenta=0;
		for(int i=1; i<=get_m(); i++){
			for(int j=1; j<=get_n(); j++){
				if(zero(M.get_matrix_item(i,j),eps))
					cuenta++;
			}
		}
		
		cout << "La matriz contiene: " << cuenta << " ceros.\n" << endl;
	}
	
	void matrix_t::maximo(matrix_t& M, double eps){
		double max = M.get_matrix_item(1,1);
		double calcula = 0;
		for(int i=1; i<=m_; i++){
			for(int j=1; j<=n_; j++){
				if( mayor(get_matrix_item(i,j), max, eps) )
				max = get_matrix_item(i,j);
			}
		}
		
		cout << "El número mayor es: " << max << endl;
		cout << endl;
	}
	// Modificación
	//     ...